#define RNG pcg32_k16384
#define TWO_ARG_INIT 1

#include "pcg-test.cpp"

