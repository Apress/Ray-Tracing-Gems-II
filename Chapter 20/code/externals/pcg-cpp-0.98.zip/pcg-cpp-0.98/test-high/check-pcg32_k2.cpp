#define RNG pcg32_k2
#define TWO_ARG_INIT 1

#include "pcg-test.cpp"

